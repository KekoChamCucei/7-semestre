# -*- coding: utf-8 -*-
"""
Created on Tue Sep  5 17:44:48 2023

@author: Roberto Anotnio García Cham

"""

#copiar un directorio completo
import shutil
import os

# Directorio de origen que deseas copiar
origen = 'C:\\Users\\Usuario\\Documents\\cham\\p2so\\raiz'

# Directorio de destino donde deseas copiar el contenido del directorio de origen
destino = 'C:\\Users\\Usuario\\Documents\\cham\\p2so\\copia'

# Copiar el directorio de origen al directorio de destino
shutil.copytree(origen, destino)

directory_path = 'C:\\Users\\Usuario\\Documents\\cham\\p2so\\copia'

# Get a list of all files in the directory
files = [f for f in os.listdir(directory_path) if os.path.isfile(os.path.join(directory_path, f))]

# Get a list of all subdirectories in the directory
subdirectories = [d for d in os.listdir(directory_path) if os.path.isdir(os.path.join(directory_path, d))]

print("Files:", files)
print("Subdirectories:", subdirectories)

"""
primero cambiamos los caracteres de los archivos encontrados

si subdirectorios no está vacío entonces entramos a ese subdirectorio y repetimos 
"""